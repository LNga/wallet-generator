const Pool = require('pg-pool');
require('dotenv').config();

const pool = new Pool({
  user: process.env.USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DATABASE,
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
});

async function createDB() {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const dropTables = 'DROP TABLE IF EXISTS players, wallets CASCADE';
    await client.query(dropTables);
    const createPlayers = `CREATE TABLE IF NOT EXISTS players (        
      "username" VARCHAR(100) PRIMARY KEY NOT NULL,
      "pwd" VARCHAR(32) NOT NULL,
      "pincode" CHAR(6) NOT NULL
    )`;
    await client.query(createPlayers);
    const createWallets = `CREATE TABLE IF NOT EXISTS wallets (
      "username" VARCHAR(100) PRIMARY KEY REFERENCES players(username),
      "wallet_address" VARCHAR(42) NOT NULL,
      "currency" VARCHAR(100) NOT NULL,
      "balance" VARCHAR(32) NOT NULL
    )`;
    await client.query(createWallets);
    const addConst = ` ALTER TABLE players
    \ ADD CONSTRAINT fk_uq1_players_wallets
    \ FOREIGN KEY (username)
    \ REFERENCES wallets (username)
    \ ON UPDATE CASCADE
    \ ON DELETE CASCADE
    \ DEFERRABLE INITIALLY DEFERRED`;
    await client.query(addConst);
    await client.query('COMMIT');
  } catch (e) {
    console.error(e.stack);
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
}

module.exports = { createDB, pool };

var express = require('express');
var router = express.Router();
const walletService = require('../../services/wallet');

router.post('/create', walletService.createWallet);

module.exports = router;
